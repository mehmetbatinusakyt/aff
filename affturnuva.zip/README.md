# next-js-11-registration-login-example

Next.js 11 - User Registration and Login Example

Documentation and live demo available at https://jasonwatmore.com/post/2021/08/19/next-js-11-user-registration-and-login-tutorial-with-example-app
